/* Copyright 2022 The MathWorks, Inc. */

#ifndef _MW_RASPI_PULSEIN_H_
#define _MW_RASPI_PULSEIN_H_

#include "rtwtypes.h"

#ifdef __cplusplus
extern "C"
{
#endif
 #if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
/* This will be used in Rapid Accelerator Mode */
#define delayMicroSec(duration) (0)
#define MW_getPulseDuration(pin, pulseState) (0)
#define MW_UltrasonicRead(duration, hasTwoPins, TrigPin, EchoPin, Trigger_Pulse_High_Duration, Trigger_Pulse_Low_Duration) (0)

#else
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include "linuxTimeLogger.h"
#include "MW_gpio.h"

uint32_T MW_getPulseDuration(uint32_T pin, uint8_T pulseState);
void MW_UltrasonicRead(uint32_T * duration, uint8_T hasTwoPins, uint8_T TrigPin, uint8_T EchoPin,
                        uint8_T Trigger_Pulse_High_Duration, uint8_T Trigger_Pulse_Low_Duration);
#endif

#ifdef __cplusplus
}
#endif

#endif